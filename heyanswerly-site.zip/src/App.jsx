import React, { useEffect } from 'react'
import {
  PhoneCall, Sparkles, Clock, CheckCircle2, ArrowRight, ShieldCheck,
  Zap, MessageSquareText, CalendarClock, Users, Mic, Headphones, Star, BadgeCheck, AlertTriangle
} from 'lucide-react'

const CAL_LINK = 'https://calendly.com/heyanswerly'

export default function App() {
  useEffect(() => {
    const a = normalizeItems(['a', '', null, undefined, 'b']).length
    console.assert(a === 2, 'normalizeItems should filter falsy values')
    const b = normalizeItems([1, 'x']).join(',')
    console.assert(b === '1,x', 'normalizeItems should cast to strings')
  }, [])

  const features = [
    { icon: <PhoneCall className="w-5 h-5" />, title: 'Answers instantly', desc: '0-1s pickup, no hold music, no menus.' },
    { icon: <Mic className="w-5 h-5" />, title: 'Sounds human', desc: 'Natural prosody, barge-in, remembers context.' },
    { icon: <CalendarClock className="w-5 h-5" />, title: 'Books & follows up', desc: 'Takes messages, books appointments, sends SMS.' },
    { icon: <ShieldCheck className="w-5 h-5" />, title: 'Private & compliant', desc: 'Built with GDPR best-practice in mind.' }
  ]

  const faqs = [
    { q: "Is this just another 'press 1 for sales' robot?", a: 'No. HeyAnswerly is a conversational AI receptionist. Callers speak naturally. It understands intent, asks clarifying questions, and completes tasks like booking or sending confirmations.' },
    { q: 'How much does it cost?', a: 'One plan: £150/month. No setup fees. Cancel anytime. Optional human transfer add-on is available if needed.' },
    { q: 'What do you need from us to set it up?', a: 'Your business hours, services/prices, booking link (if any), and a mobile number for urgent escalations. We will upload FAQs so it speaks in your brand voice.' },
    { q: 'Is call recording required?', a: 'No. It is optional. If enabled, we announce recording at the start of the call for compliance.' }
  ]

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      {/* Nav */}
      <header className="sticky top-0 z-40 backdrop-blur border-b border-white/10 bg-neutral-950/70">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Logo */}
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 grid place-items-center relative overflow-hidden">
              <svg viewBox="0 0 64 64" className="w-6 h-6" aria-label="HeyAnswerly logo">
                <defs>
                  <linearGradient id="haGrad2" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#3ba6ff" />
                    <stop offset="100%" stopColor="#2f61ff" />
                  </linearGradient>
                </defs>
                <path d="M18 10h28c5 0 8 3 8 8v20c0 5-3 8-8 8H30l-6 6v-6H18c-5 0-8-3-8-8V18c0-5 3-8 8-8z" fill="url(#haGrad2)" />
                <path d="M26 23c2 6 9 13 15 15l4-4c1-1 3-1 4 0l4 3c1 1 1 3 0 4-3 3-6 5-10 5-10 0-23-13-23-23 0-4 2-7 5-10 1-1 3-1 4 0l3 4c1 1 1 3 0 4l-4 4z" fill="#fff" />
              </svg>
            </div>
            <span className="font-semibold tracking-tight">HeyAnswerly</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm text-neutral-300">
            <a href="#how" className="hover:text-white">How it works</a>
            <a href="#compare" className="hover:text-white">Why we are different</a>
            <a href="#pricing" className="hover:text-white">Pricing</a>
            <a href="#faq" className="hover:text-white">FAQ</a>
            <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="hover:text-white">Book a call</a>
          </nav>
          <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="group inline-flex items-center gap-2 rounded-xl bg-indigo-500 px-4 py-2 text-sm font-medium hover:bg-indigo-400 transition">
            Book on Calendly <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition" />
          </a>
        </div>
      </header>

      {/* Hero */}
      <section>
        <div className="max-w-6xl mx-auto px-4 py-20 lg:py-28 grid lg:grid-cols-2 gap-12">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-neutral-300">
              <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
              New: Human-sounding AI receptionist, 24/7
            </div>
            <h1 className="mt-4 text-4xl/tight md:text-5xl/tight font-semibold">
              Never miss another call.
              <span className="block text-neutral-400">The AI receptionist that sounds human.</span>
            </h1>
            <p className="mt-5 text-neutral-300 max-w-xl">
              Old phone trees make customers hang up. HeyAnswerly answers in a second, has a natural conversation, books appointments, and sends you every lead, day or night.
            </p>
            <div className="mt-8">
              <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-500 px-5 py-3 font-medium hover:bg-indigo-400 transition">
                Book on Calendly <ArrowRight className="w-4 h-4" />
              </a>
            </div>
            <div className="mt-6 flex items-center gap-4 text-sm text-neutral-400">
              <div className="inline-flex items-center gap-2"><Clock className="w-4 h-4" /> 24/7 coverage</div>
              <div className="inline-flex items-center gap-2"><BadgeCheck className="w-4 h-4" /> 14-day refund guarantee</div>
              <div className="inline-flex items-center gap-2"><Star className="w-4 h-4" /> Early access: limited spots</div>
            </div>
          </div>

          <div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-2xl">
              <div className="text-sm text-neutral-300">Live demo transcript</div>
              <div className="mt-3 space-y-3 text-sm">
                <ChatBubble who="Caller" text="Hi, can I book a cut and beard trim for Friday?" />
                <ChatBubble who="HeyAnswerly" text="Absolutely. Morning or afternoon?" ai />
                <ChatBubble who="Caller" text="Afternoon, around 2pm." />
                <ChatBubble who="HeyAnswerly" text="Got it. I can do 2:15pm with Jamie. Shall I confirm and text you the details?" ai />
                <ChatBubble who="Caller" text="Yes please." />
                <ChatBubble who="HeyAnswerly" text="All set. I have booked you for Friday 2:15pm with Jamie and sent a confirmation SMS. Anything else I can help with?" ai />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Book a call */}
      <section id="book" className="py-12 border-t border-white/10 bg-neutral-900/40">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-6 items-center">
          <div>
            <h2 className="text-2xl md:text-3xl font-semibold">Book your setup call</h2>
            <p className="mt-2 text-neutral-300 max-w-xl">Pick a free 15-minute slot and we will walk you through setup and a live demo.</p>
          </div>
          <div className="md:text-right">
            <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-indigo-500 px-5 py-3 font-medium hover:bg-indigo-400 transition">
              Book on Calendly <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-16 border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold">How it works</h2>
          <p className="mt-2 text-neutral-300 max-w-2xl">Connect your number, upload FAQs, and HeyAnswerly handles the rest. Setup takes under an hour.</p>
          <div className="mt-8 grid md:grid-cols-4 gap-4">
            <CardStep icon={<PhoneCall className="w-5 h-5" />} title="Connect" desc="We attach your business number and set the greeting." idx={1} />
            <CardStep icon={<MessageSquareText className="w-5 h-5" />} title="Train" desc="We add your prices, services, and policies." idx={2} />
            <CardStep icon={<CalendarClock className="w-5 h-5" />} title="Book" desc="It answers calls, books slots, and sends SMS leads." idx={3} />
            <CardStep icon={<ShieldCheck className="w-5 h-5" />} title="Report" desc="Daily summaries and transcripts in your inbox." idx={4} />
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section id="compare" className="py-16 border-t border-white/10 bg-neutral-900/40">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold">Old robots vs HeyAnswerly</h2>
          <p className="mt-2 text-neutral-300 max-w-2xl">The difference your callers will hear immediately.</p>
          <div className="mt-8 grid md:grid-cols-2 gap-6">
            <div className="rounded-2xl border border-white/10 p-6 bg-black/30">
              <div className="text-neutral-400 text-sm mb-3">Legacy phone trees</div>
              <BadList items={["'Press 1 for...' menus and hold music","Robotic tone, no empathy or memory","Limited to taking messages","Office hours only","High bounce: customers hang up"]} />
            </div>
            <div className="rounded-2xl border border-white/10 p-6 bg-white/5">
              <div className="text-neutral-300 text-sm mb-3">HeyAnswerly</div>
              <GoodList items={["Instant, natural conversation","Understands intent; asks clarifying questions","Books real appointments and sends confirmations","Always on: 24/7/365","Happy callers, more completed bookings"]} />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold">What you get</h2>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <div key={i} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="flex items-center gap-2 text-indigo-300">{f.icon}<span className="text-sm uppercase tracking-wide text-indigo-200/90">Feature</span></div>
                <div className="mt-2 font-medium">{f.title}</div>
                <div className="mt-1 text-sm text-neutral-300">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-16 border-t border-white/10 bg-neutral-900/40">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold">Simple pricing</h2>
          <p className="mt-2 text-neutral-300">One plan. No surprises. Early access is limited due to server capacity.</p>
          <div className="mt-8 grid lg:grid-cols-2 gap-6">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <div className="text-sm text-neutral-400">HeyAnswerly Plan</div>
              <div className="mt-2 flex items-baseline gap-2">
                <div className="text-4xl font-semibold">£150</div>
                <div className="text-neutral-400">/month</div>
              </div>
              <ul className="mt-4 space-y-3 text-sm">
                <Li>24/7 AI receptionist (natural voice)</Li>
                <Li>1 business number included</Li>
                <Li>Booking, messages, SMS lead alerts</Li>
                <Li>Daily call summaries and transcripts</Li>
                <Li>Fair use: designed for typical SMB volumes</Li>
                <Li className="text-neutral-300/80">Optional human transfer add-on</Li>
              </ul>
              <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-indigo-500 px-5 py-3 font-medium hover:bg-indigo-400 transition">
                Book on Calendly <ArrowRight className="w-4 h-4" />
              </a>
            </div>
            <div className="rounded-3xl border border-white/10 bg-black/30 p-6">
              <div className="text-sm text-neutral-400">Why this and why now</div>
              <h3 className="mt-2 text-xl font-semibold">Built after years of real-world testing</h3>
              <p className="mt-2 text-neutral-300">We have been refining lifelike voice AI for years: testing hundreds of models, prompts, and call flows. The result is an AI that sounds human, responds instantly, and books customers in without friction. Capacity is limited while we scale servers, so we are onboarding a small number of businesses this month.</p>
              <div className="mt-4 flex flex-wrap gap-3 text-sm text-neutral-300">
                <Pill icon={<Zap className="w-3.5 h-3.5" />} text="<1s first response" />
                <Pill icon={<Headphones className="w-3.5 h-3.5" />} text="Barge-in, natural prosody" />
                <Pill icon={<Users className="w-3.5 h-3.5" />} text="Trained on your FAQs" />
                <Pill icon={<ShieldCheck className="w-3.5 h-3.5" />} text="GDPR-aware flows" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16 border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold">FAQ</h2>
          <div className="mt-6 grid md:grid-cols-2 gap-6">
            {faqs.map((f, i) => (
              <div key={i} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="font-medium">{f.q}</div>
                <div className="mt-1 text-neutral-300 text-sm">{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Apply */}
      <section id="apply" className="py-16 border-t border-white/10 bg-neutral-900/40">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-semibold">Ready to get started?</h2>
          <p className="mt-2 text-neutral-300">Book a free 15-minute setup call and we will activate your HeyAnswerly line.</p>
          <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-indigo-500 px-6 py-3 font-medium hover:bg-indigo-400 transition">
            Book on Calendly <ArrowRight className="w-4 h-4" />
          </a>
          <p className="mt-3 text-xs text-neutral-400">If your preview blocks new tabs, copy this link: <code className="select-all">https://calendly.com/heyanswerly</code></p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-8 text-sm text-neutral-400 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>© {new Date().getFullYear()} HeyAnswerly. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-neutral-200">Terms</a>
            <a href="#" className="hover:text-neutral-200">Privacy</a>
            <a href={CAL_LINK} target="_blank" rel="noopener noreferrer" className="hover:text-neutral-200">Book a call</a>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Shared UI bits
function ChatBubble({ who, text, ai }) {
  return (
    <div className={\`flex gap-3 \${ai ? 'flex-row' : 'flex-row-reverse'}\`}>
      <div className={\`rounded-2xl px-3 py-2 text-sm max-w-[28rem] \${ai ? 'bg-white/5 border border-white/10' : 'bg-indigo-500/10 border border-indigo-500/20'}\`}>
        <div className="text-xs mb-0.5 text-neutral-400">{who}</div>
        <div className="text-neutral-200">{text}</div>
      </div>
    </div>
  )
}

function CardStep({ icon, title, desc, idx }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <div className="flex items-center gap-2 text-indigo-300"><span className="inline-flex w-6 h-6 items-center justify-center rounded-lg bg-indigo-500/20 text-xs font-medium">{idx}</span>{icon}</div>
      <div className="mt-2 font-medium">{title}</div>
      <div className="mt-1 text-sm text-neutral-300">{desc}</div>
    </div>
  )
}

function Li({ children, className = '' }) {
  return (
    <li className={\`flex items-start gap-2 \${className}\`}>
      <CheckCircle2 className="w-4 h-4 mt-0.5 text-indigo-300" />
      <span>{children}</span>
    </li>
  )
}

function Pill({ icon, text }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-neutral-200">
      {icon}
      {text}
    </span>
  )
}

function GoodList({ items }) {
  const safe = normalizeItems(items)
  return (
    <ul className="space-y-3">
      {safe.map((t, i) => (
        <li key={i} className="flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 mt-0.5 text-emerald-400" />
          <span className="text-sm text-neutral-200">{t}</span>
        </li>
      ))}
    </ul>
  )
}

function BadList({ items }) {
  const safe = normalizeItems(items)
  return (
    <ul className="space-y-3">
      {safe.map((t, i) => (
        <li key={i} className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 mt-0.5 text-rose-400" />
          <span className="text-sm text-neutral-300">{t}</span>
        </li>
      ))}
    </ul>
  )
}

function normalizeItems(items) {
  return items.filter(Boolean).map(String);
}
